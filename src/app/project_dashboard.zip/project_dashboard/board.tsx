import React from 'react';
import DoughnutChart from '../component/donutChart';

function Board() {
    return (
        <DoughnutChart/>
    );
}

export default Board;